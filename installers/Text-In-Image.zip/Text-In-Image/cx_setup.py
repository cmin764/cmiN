from cx_Freeze import setup, Executable

executables = [
    Executable(
        script="tii.pyw",
        initScript=None,
        base='Win32GUI', # Win32GUI/Console
        compress=True,
        appendScriptToExe=True,
        appendScriptToLibrary=False,
        icon="tii.ico",
        copyDependentFiles=True
    )
]

setup(
    version="1.1",
    description="Hide text in pictures.",
    author="cmiN",
    name="Text In Image",
    options=
    {
        "build_exe":
        {
            "optimize": 2,
            "compressed": True,
            "create_shared_zip": False,
            "include_in_shared_zip": False,
            "append_script_to_exe": True,
            "copy_dependent_files": True
        }
    },
    executables=executables
)
